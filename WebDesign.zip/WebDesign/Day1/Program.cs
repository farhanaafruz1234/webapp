﻿using System;

namespace Day1
{
    class Program
    {
        static void Main(string[] args)
        {

            //Program.Initials();
            //Program.UseClass();
            //Program.UseConstructor();
           // Program.UseMethod();
            //Program.USeParams();
            Program.UseEncapsulation();


        }


        static void Initials()
        {
            Console.WriteLine("Welcome to CSE 309");
        }

        static void UseClass()
        {
            try
            {
                Customer customer = new Customer();
                //var customer = new Customer();
                customer.Name = "Anonymous";
                customer.Introduce("guys");
                var age = customer.Age(20);
                var salary = customer.Salary(1000.50);
                var isMarried = customer.IsMarried(true) ? "Married" : "Not Married";
                Console.WriteLine("My age is {0}", age);
                Console.WriteLine("My salary is {0}", salary);
                Console.WriteLine("I am {0}", isMarried);

            }
            catch (Exception)
            {

                Console.WriteLine("Exception happens");
            }
           
        }

        // Fields example
        static void UseConstructor()
        {
            //var client = new Client(1, "anonymous");
            //var order = new Order();
            //client.Orders.Add(order);
            ///// object initializer example
            ///

            //var client1 = new Client();
            var client = new Client
            {
                Id = 1,
                Name = "Anonymous"

            };

            client.Orders.Add(new Order());
            client.Orders.Add(new Order());

            client.Promote();

            Console.WriteLine(client.Orders.Count);

            Console.WriteLine(client.Id);
            Console.WriteLine(client.Name);

        }

        static void UseMethod()
        {
            try
            {
                var point = new Point(10, 20);
                //point.Move(20, 30);
                point.Move(20, 40);
                Console.WriteLine("Point is at {0} and {1}", point.X, point.Y);

                point.Move(20, 40, 60);
                Console.WriteLine("Point is at {0} , {1} and {2}", point.X, point.Y, point.Z);

            }
            catch (Exception)
            {

                Console.WriteLine("Exception happens");
            }

        }

        static void USeParams()
        {
            var calculator = new Calculator();
            Console.WriteLine(calculator.Add(2, 3, 4));
            Console.WriteLine(calculator.Add(2, 3, 4,5));

            //Console.WriteLine(calculator.Add( new int[] { 2, 3, 4, 5,6 }));

        }

        static void UseEncapsulation()
        {
            var player = new Player();
            
            player.SetBirthDate(new DateTime(1997,12,1));
            Console.WriteLine(player.GetBirthDate());
        }



    }
}

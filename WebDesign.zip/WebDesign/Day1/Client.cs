﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day1
{
    //constructor example
    // when we really need to instantiate object earlier
    class Client
    {
        public int Id;
        public string Name;
      //  public List<Order> Orders;
        public readonly List<Order> Orders = new List<Order>();

        public Client()
        {
           // Orders = new List<Order>();
        }

        //we use constructor to initialize field value
        public Client(int id)
            :this()
        {
            this.Id = id;
        }
        // overloading constructor

        public Client(int id, string name)
            :this(id)
        {
            this.Name = name;

        }

        public void Promote()
        {
           // Orders = new List<Order>();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day1
{
    //Class Example
    public class Customer
    {
        public string Name;

        public void Introduce (string to)
        {
            Console.WriteLine("hi {0} I am {1}", to, Name );
        }

        public int Age(int age)
        {
            return age;
        }

        public double Salary(double salary)
        {
            return salary;
        }

        public bool IsMarried(bool isMarried)
        {
            return isMarried;
            
        }
       


    }
}

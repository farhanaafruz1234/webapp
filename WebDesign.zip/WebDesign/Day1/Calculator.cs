﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day1
{
    public class Calculator
    {
        //params keyword in C# can be used to
        //declare method that does not know the number of parameters.
        //Parmas are also useful to write "clean code".
        //Instead of using various overloaded methods to pass multiple values,
        //we can simply create an array and pass it as an arugment or a comma separated list of values.

        //For example, a Student class with a method, TotalMarks that returns the sum of all marks.Each grade may have a different number of subjects and their respective marks.The 3rd grade may have 3 subjects only.The 8th grade may have 4 subjects while a 9th grade may have 5 subjects.We can use params in this case and pass 3, 4, and 5 comma separated values.



        public int Add(params int[] numbers)
        {
            var sum = 0;
            foreach(var number in numbers)
            {
                sum += number;
            }
            return sum;
        }
    }
}

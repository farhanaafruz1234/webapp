﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day1
{
    public class Player
    {
        private DateTime birthDate;

        public void SetBirthDate(DateTime birthDate)
        {
            this.birthDate = birthDate;
        }

        public DateTime GetBirthDate()
        {
            return birthDate;
        }
    }
}

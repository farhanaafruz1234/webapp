﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    interface Vehiccle
    {
        void changeGear(int a);
        void speedUp(int a);
        void applyBrakes(int a);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    public class Vehicle
    {
        public void PrintMessage()
        {
            Console.WriteLine("This is Vehicle class");
        }
    }
}

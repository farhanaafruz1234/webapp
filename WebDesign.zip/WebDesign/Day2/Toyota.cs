﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    public class Toyota
    {
        private readonly Vehicle _vehicle;
        public Toyota(Vehicle vehicle)
        {
            _vehicle = vehicle;
        }

        public void PrintMessage()
        {
            _vehicle.PrintMessage();
        }
    }
}

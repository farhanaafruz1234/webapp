﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    public class Account
    {
       
        
        public double CreditAccount(double currentBalance, double value)
        {
            
            return currentBalance + value;
        }

        public double DebitAccount(double currentBalance,double value)
        {
            
            return currentBalance - value;
        }






    }
}

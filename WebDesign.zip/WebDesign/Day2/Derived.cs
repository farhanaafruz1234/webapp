﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    class Derived:Base
    {
        public override void printMessage()
        {
            Console.WriteLine("This is Derived class");
        }
    }
}

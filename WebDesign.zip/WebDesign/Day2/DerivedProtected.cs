﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
     class DerivedProtected:ProtectedAccess
    {
        public string GetProName()
        {
            return proname;
        }
    }
}

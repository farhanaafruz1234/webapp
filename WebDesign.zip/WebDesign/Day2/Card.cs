﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    public class Card:Account
    {
        public double WithDrawMoney(double currentbalance,double value)
        {
            return currentbalance - value;

        }
    }
}

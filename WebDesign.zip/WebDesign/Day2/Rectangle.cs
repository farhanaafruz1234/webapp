﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    class Rectangle : Shape
    {
        public override void Draw()
        {
            Console.WriteLine("Rectange is drawn");
        }
    }
}

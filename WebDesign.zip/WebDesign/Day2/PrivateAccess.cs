﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    class PrivateAccess
    {
        private string pname;
        //string pname;

        public void SetName(string name)
        {
            pname = name;
        }

        public string GetName()
        {
            return pname;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
   class ProtectedAccess
    {
        protected string proname;

        public void SetProName(string name)
        {
            proname = name;
        }

    }
}

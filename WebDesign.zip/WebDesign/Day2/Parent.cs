﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    class Parent
    {
        public void Work()
        {
            Console.WriteLine("This is Working...");
        }
    }
}

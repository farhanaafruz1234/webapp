﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Day2
{
    class Base
    {
        public virtual void printMessage()
        {
            Console.WriteLine("This is Base class");
        }
    }
}

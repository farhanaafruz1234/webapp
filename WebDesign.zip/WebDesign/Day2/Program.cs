﻿using System;

namespace Day2
{
    class Program
    {
        static void Main(string[] args)
        {
            //InheritanceExample();
            //CompositionExample();
            //AccessModifierExample();
            //UpcastDowncastExample();
            BoxingUnBoxing();
            //MethodOverRiding();
            //AbstractExample();
            //InterfaceExample();


        }

        static void CompositionExample()
        {
            var toyota = new Toyota(new Vehicle());
            toyota.PrintMessage();
        }

        static void InheritanceExample()
        {
            var card = new Card();
            var credit = card.CreditAccount(1000, 1000);
            var debit = card.DebitAccount(2000, 1000);
            var withDraw = card.WithDrawMoney(2000, 1000);

            Console.WriteLine("After Credit {0}", credit);
            Console.WriteLine("After Debit {0}", debit);
            Console.WriteLine("After withDraw {0}", withDraw);

        }


        static void AccessModifierExample()
        {
            //public There are no restrictions on accessing public members.
            //private Access is limited to within the class definition. This is the default access modifier type if none is formally specified
            //protected Access is limited to within the class definition and any class that inherits from the class
            //internal Access is limited exclusively to classes defined within the current project assembly

            var ob1 = new PublicAccess();
            //Direct access to public members  
            ob1.name = "This is public field";
            Console.WriteLine( ob1.name);

            var ob2 = new PrivateAccess();
            ////Access to private member is not permitted . What to do ? use setter getter  
            //ob2.pname = "This is private field";
            //Console.WriteLine(ob2.pname);

            ob2.SetName("This is private field");
            Console.WriteLine(ob2.GetName());

            //var ob3 = new ProtectedAccess();
            //ob3.proname = "This is protected field"

            var ob4 = new DerivedProtected();
            ob4.SetProName("This is protected field");
            Console.WriteLine(ob4.GetProName()); 




        }

        static void UpcastDowncastExample()
        {
            //Downcast, as the name suggests, is the process of going down from the top
            //i.e, from Super class to Sub class.
            //"A child class can always refer to its parent class but the parent class can't refer to its child class."

            Parent parent1 = new Child(); //Assigning child object to parent ref. variable  
            Child child1 = (Child)parent1; //Down cast parent ref. variable to child.  
            child1.Sleep(); //Calling child class sleep method and it will work fine. 


            //In Upcast we need not explicitly cast the object as we are going upwards to the parent class.

            Child child2 = new Child();
            Parent parent2 = child2; // Upcasting with no explicit cast.  
            parent2.Work(); // Parent class work method will run. Because we know that a child can always refer to parent class.   


        }


        static void BoxingUnBoxing()
        {
            //The process of Converting a Value Type (char, int etc.) to a Reference Type(object) is called Boxing.
            //Boxing is implicit conversion process
            int year = 2021;
            object ob = year; // boxing
            year = 2050;
            Console.WriteLine("Year : {0}  object: {1}",year,ob);

            //The process of converting reference type into the value type is known as Unboxing.
            //It is explicit conversion process.

            
            object obj = 5;            
            int value = (int)obj;            // unboxing

            Console.WriteLine("Year : {0}  object: {1}", obj,value);

        }


        static void MethodOverRiding()
        {
            // Method overriding means changing the implementation of an inherited method.
            // If a declare a method as virtual in the base class, we can override it in a derived class

            Base ob; 

            ob = new Base();
            ob.printMessage();

            ob = new Derived();
            ob.printMessage();

        }



        static void AbstractExample()
        {
            //Abstract modifier states that a class or a member misses implementation.We use
            //abstract members when it doesn’t make sense to implement them in a base class. For
            //example, the concept of drawing a shape is too abstract. We don’t know how to draw
            //a shape.This needs to be implemented in the derived classes.

            //When a class member is declared as abstract, that class needs to be declared as
            //abstract as well.That means that class is not complete.

            //In derived classes, we need to override the abstract members in the base class.
            Shape s;

            s = new Rectangle();
            s.Draw();

            s = new Circle();
            s.Draw();
            



        }

        static void InterfaceExample()
        {
            //Abstract class can contain methods, fields, constants, etc.
            //Interface can only contain methods.
            //Abstracrt can contain static members and constructor whereas interface not.

            BiCycle bicycle = new BiCycle();
            bicycle.changeGear(2);
            bicycle.speedUp(3);
            bicycle.applyBrakes(1);

            Console.WriteLine("Bicycle present state :");
            bicycle.printStates();
        }

    }
}
